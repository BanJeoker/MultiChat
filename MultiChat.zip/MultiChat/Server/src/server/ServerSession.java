package server;

import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;


public class ServerSession extends Thread{
    private  Socket clientSocket;
    private  Server server;
    private OutputStream outputStream;



    private String userID;
    private HashMap<String,String> userList=new HashMap<>();
    private String userName;



    public ServerSession(Server server, Socket clientSocket) throws IOException {
        this.server=server;
        this.clientSocket=clientSocket;
        fillUserList();



    }

    private void fillUserList() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("/Users/macbookpro/IdeaProjects/MultiChat/Server/src/server/data/userList.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] lines=StringUtils.split(line);
            userList.put(lines[0],lines[1]);
        }
    }

    private String getUserName() throws IOException {
        String userName="";
        BufferedReader br = new BufferedReader(new FileReader("/Users/macbookpro/IdeaProjects/MultiChat/Server/src/server/data/userList.txt"));
            String line;
            while ((line = br.readLine()) != null) {
                String[] lines=StringUtils.split(line);
                if (!lines[0].equals(userID)){
                    userName=userName+lines[0]+" ";
                }
            }
        return userName;
    }


    @Override
    public void run() {
        try {
            ClientSocketStart();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void ClientSocketStart() throws IOException {
        InputStream inputStream=clientSocket.getInputStream();
        outputStream=clientSocket.getOutputStream();
        BufferedReader reader=new BufferedReader(new InputStreamReader(inputStream));
        String request="";
//        System.out.println("1111111");
        while((request=reader.readLine())!=null){
//            System.out.println(request);
            String[] requests= StringUtils.split(request);

            String cmd=requests[0];
            if("LOGON".equals(cmd)){
                handleLogin(outputStream,requests);
            }
        }
        clientSocket.close();
    }

    private void handleLogin(OutputStream outputStream, String[] requests) throws IOException {

        String userID=requests[1];
        String password=requests[2];

        if(passwordRight(userID,password)){
                this.userID=userID;
                userName=getUserName();
                String msg="LOGOK 100 "+userID+" "+userName+"\n";      //need to change
//                String response="LOGFAIL "+userID+" "+"wrong name or password\n";
//                String msg="LOGOK 100 "+userID;
//                String msg="LOGFAIL "+userID+" "+"wrong name or password\n";
                outputStream.write(msg.getBytes());

                System.out.println(userID+" has logged in successfully");

                ArrayList<ServerSession> serverSessionList=server.getServerSessions();
                 for (ServerSession session:serverSessionList){
                     if (session.getUserID()!=null&&!userID.equals(session.getUserID())){
                         String onlineMsg="ONLINE "+session.getUserID()+"\n";
                         sendMsg(onlineMsg);
                     }
                 }
                for (ServerSession session:serverSessionList){
                    if (session.getUserID()!=null&&!userID.equals(session.getUserID())){
                        String onlineMsg="ONLINE "+userID+"\n";
                        session.sendMsg(onlineMsg);
                    }
                }


        }
        else{
            String response="LOGFAIL "+userID+" "+"wrong name or password\n";
            outputStream.write(response.getBytes());
            System.out.println(userID+" fails to login");
        }
    }

    private void sendMsg(String msg) throws IOException {
        if (userID!=null){
            outputStream.write(msg.getBytes());
        }
    }

    private boolean checkBufferMsg(String userID) {
        return false;
    }

    private boolean passwordRight(String userID, String password) {
        if(!userList.containsKey(userID)){
            return false;
        }
        else{
            String pass=userList.get(userID);
            if (pass.equals(password)){
                return true;
            }
            else {
                return false;
            }
        }

    }
    public String getUserID() {
        return userID;
    }

}

