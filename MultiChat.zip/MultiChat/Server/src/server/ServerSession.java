package server;

import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;


public class ServerSession extends Thread{
    private  Socket clientSocket;
    private  Server server;
    private OutputStream outputStream;



    private String userID;
    private HashMap<String,String> userList=new HashMap<>();
    private String userName;

    private BufferedWriter bw=null;
    private FileWriter fw=null;



    public ServerSession(Server server, Socket clientSocket) throws IOException {
        this.server=server;
        this.clientSocket=clientSocket;
        fillUserList();



    }

    private void fillUserList() throws IOException {
//        BufferedReader br = new BufferedReader(new FileReader("/Users/macbookpro/IdeaProjects/MultiChat/Server/src/server/data/userList.txt"));
        BufferedReader br = new BufferedReader(new FileReader("./Server/src/server/data/userList.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            String[] lines=StringUtils.split(line);
            userList.put(lines[0],lines[1]);
        }
    }

    private String getUserName() throws IOException {
        String userName="";
//        BufferedReader br = new BufferedReader(new FileReader("/Users/macbookpro/IdeaProjects/MultiChat/Server/src/server/data/userList.txt"));
        BufferedReader br = new BufferedReader(new FileReader("./Server/src/server/data/userList.txt"));

        String line;

            while ((line = br.readLine()) != null) {
                String[] lines=StringUtils.split(line);
                if (!lines[0].equals(userID)){
                    userName=userName+lines[0]+" ";
                }
            }
        return userName;
    }


    @Override
    public void run() {
        try {
            ClientSocketStart();


        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void ClientSocketStart() throws IOException, InterruptedException, SocketException {
        try {
            InputStream inputStream = clientSocket.getInputStream();
            outputStream = clientSocket.getOutputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String request = "";
//        System.out.println("1111111");
            while ((request = reader.readLine()) != null) {


                String[] requests = StringUtils.split(request);

                String cmd = requests[0];
                if ("LOGON".equals(cmd)) {
                    handleLogin(outputStream, requests);
                } else if ("SEND".equals(cmd)) {
                    String tempmsg = "" + request;

                    while (!request.equals("over")) {
                        request = reader.readLine();
                        if (request.equals("over")) {
//                        System.out.println("right before tempmsg "+tempmsg);
                            tempmsg = tempmsg + "\n" + request;
                            handleSend(outputStream, tempmsg);
                            break;
                        }
                        tempmsg = tempmsg + "\n" + request;

                    }
                }
                else if ("LOGOFF".equals(cmd)) {

                    server.removeSession(this);
                    ArrayList<ServerSession> serverSessionList = server.getServerSessions();
                    for (ServerSession session : serverSessionList) {
                        if (session.getUserID() != null && !userID.equals(session.getUserID())) {
                            session.sendMsg(request+"\n");
                            break;
                        }
                    }
                    clientSocket.close();
                    System.out.println(userID+" has logged off");
                    reader.close();
                }
                else if("REG".equals(cmd)){
                    handleRegister(requests[1],requests[2]);
                    clientSocket.close();
                    reader.close();
                }
            }
        }
        catch (IOException e){

        }

    }

    private void handleRegister(String username,String password) throws IOException {
        fillUserList();
        if(userList.containsKey(username)){
            String msg="DUP "+username+"\n";
            outputStream.write(msg.getBytes());
        }
        else{
            //update serverText
            String filename="./Server/src/server/data/userList.txt";
            fw=new FileWriter(filename,true);
            bw=new BufferedWriter(fw);
            String usermsg=username+" "+password+"\n";
            bw.write(usermsg);
            if (bw != null){ bw.close(); }
            if (fw != null){ fw.close(); }

            //update bufferText
            String newfilename="./Server/src/server/data/BufferedMsg/"+username+".txt";
            File file = new File(newfilename);
            file.createNewFile();
            //send new user to all online user
            ArrayList<ServerSession> serverSessionList=server.getServerSessions();
            String newUserUpdateMsg="UPDATE "+username+"\n";
            for (ServerSession session:serverSessionList){
                if (session.getUserID()!=null){
                    session.sendMsg(newUserUpdateMsg);
                }
            }
            //send register ok msg
            String msg="REGOK "+username+"\n";
            outputStream.write(msg.getBytes());
        }



    }

    private void handleSend(OutputStream outputStream, String request) throws IOException {
        String[] requests=StringUtils.split(request,null,6);

        String sender=requests[1];
        String recipient=requests[2];
        String time=requests[3]+" "+requests[4];
        String content=requests[5];
//        System.out.println("content is "+content);
        String msg="MSG "+sender+" "+recipient+" "+time+" "+content+"\n";

//        System.out.println("msg is"+msg);
        if(checkRecipientOnline(recipient)){
            ArrayList<ServerSession> serverSessionList=server.getServerSessions();
            for (ServerSession session:serverSessionList){
                if (session.getUserID()!=null&&recipient.equals(session.getUserID())){
//                        System.out.println("the message was sent to"+session.getUserID());
                        session.sendMsg(msg);
                        break;
                }
            }


        }
        else{

//            String filename="/Users/macbookpro/IdeaProjects/MultiChat/Server/src/server/data/BufferedMsg/"+recipient+".txt";
            String filename="./Server/src/server/data/BufferedMsg/"+recipient+".txt";


            fw=new FileWriter(filename,true);
            bw=new BufferedWriter(fw);
            String bufferedMsg=request+"\n";

            File newFile = new File(filename);
            if (newFile.length() != 0) {
                bw.write("\n");
            }
            bw.write(request);
            if (bw != null){ bw.close(); }
            if (fw != null){ fw.close(); }
        }
    }

    private boolean checkRecipientOnline(String recipient) {
        ArrayList<ServerSession> serverSessionList=server.getServerSessions();
        for (ServerSession session:serverSessionList){
            if (session.getUserID()!=null&&recipient.equals(session.getUserID())){
                return true;
            }
        }
        return false;
    }

    private void handleLogin(OutputStream outputStream, String[] requests) throws IOException, InterruptedException {

        String userID=requests[1];
        String password=requests[2];

        if(passwordRight(userID,password)){
                boolean hasBufferedMsgFlag=false;
                this.userID=userID;
                userName=getUserName();
                String filename="./Server/src/server/data/BufferedMsg/"+userID+".txt";

//                String filename="/Users/macbookpro/IdeaProjects/MultiChat/Server/src/server/data/BufferedMsg/"+userID+".txt";
                File newFile = new File(filename);
                String msg="";
                if (newFile.length() != 0) {
                    hasBufferedMsgFlag=true;
                    msg="LOGOK 200 "+userID+" "+userName+"\n";
                }
                else{
                    msg="LOGOK 100 "+userID+" "+userName+"\n";
                }

                outputStream.write(msg.getBytes());

                System.out.println(userID+" has logged in successfully");

                Thread.sleep(1000);
                ArrayList<ServerSession> serverSessionList=server.getServerSessions();
                 for (ServerSession session:serverSessionList){
                     if (session.getUserID()!=null&&!userID.equals(session.getUserID())){
                         String onlineMsg="ONLINE "+session.getUserID()+"\n";
                         sendMsg(onlineMsg);
                     }
                 }
                for (ServerSession session:serverSessionList){
                    if (session.getUserID()!=null&&!userID.equals(session.getUserID())){
                        String onlineMsg="ONLINE "+userID+"\n";
                        session.sendMsg(onlineMsg);
                    }
                }

                //check if there are buffered msgs
//                handleSend(outputStream,tempmsg);
                if(hasBufferedMsgFlag){
//                    Thread.sleep(1000);
                    BufferedReader br = new BufferedReader(new FileReader(filename));
                    String line;
                    String tempMsg="";
                    while ((line = br.readLine()) != null) {
                        if (line.equals("over")){
                            tempMsg=tempMsg+""+line;
                            handleSend(outputStream,tempMsg);
//                            Thread.sleep(500);
                            System.out.println("this message is:"+tempMsg);
                            tempMsg="";
                        }
                        else{
                            tempMsg=tempMsg+""+line+"\n";
                        }
                    }

                    //empty the buffer
                    fw=new FileWriter(filename);
                    bw=new BufferedWriter(fw);
                    bw.write("");
                    if (bw != null){ bw.close(); }
                    if (fw != null){ fw.close(); }


                }

        }
        else{
            String response="LOGFAIL "+userID+" "+"wrong name or password\n";
            outputStream.write(response.getBytes());
            System.out.println(userID+" fails to login");
        }
    }

    private void sendMsg(String msg) throws IOException {
        if (userID!=null&&!msg.equals("")){
//            System.out.println("here msg is"+msg);
            outputStream.write(msg.getBytes());
        }
    }

    private boolean checkBufferMsg(String userID) {
        return false;
    }

    private boolean passwordRight(String userID, String password) {
        if(!userList.containsKey(userID)){
            return false;
        }
        else{
            String pass=userList.get(userID);
            if (pass.equals(password)){
                return true;
            }
            else {
                return false;
            }
        }

    }
    public String getUserID() {
        return userID;
    }

}

