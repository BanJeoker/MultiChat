package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Server extends Thread{
    private int port;
    private Map<String,String> userPassword=new HashMap<>();
    private ArrayList<ServerSession> serverSessions=new ArrayList<>();

    public Server(int port) {
        this.port=port;
        userPassword.put("jim","123");
        userPassword.put("eric","456");
        userPassword.put("james","abc");
    }


    @Override
    public void run() {
        try {
            ServerSocket serverSocket=new ServerSocket(port);
            while (true){
                System.out.println("Server Started");
                Socket clientSocket=serverSocket.accept();
                System.out.println("Server accepts connection from  "+ serverSocket);
                ServerSession session=new ServerSession(this,clientSocket);
                serverSessions.add(session);
                session.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }






    //get and setter
    public ArrayList<ServerSession> getServerSessions() {
        return serverSessions;
    }
    public Map<String, String> getUserPassword() {
        return userPassword;
    }
    public void removeSession(ServerSession serverSession){
        serverSessions.remove(serverSession);

    }
}


