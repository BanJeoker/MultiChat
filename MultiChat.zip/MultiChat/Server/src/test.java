import org.apache.commons.lang3.StringUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class test {
    public static void main(String[] args) throws ParseException {

//        name1.setText(names[0]);
//        name2.setText(names[1]);
//        name3.setText(names[2]);
//        name4.setText(names[3]);
//        name5.setText(names[4]);
//        name6.setText(names[5]);
//        name7.setText(names[6]);
//        name8.setText(names[7]);
//        name9.setText(names[8]);
//        name10.setText(names[9]);

//        online1.setText(onlineStatus[0]);
//        online1.setTextFill(Paint.valueOf("#ff0000"));
//        online2.setText(onlineStatus[1]);
//        online2.setTextFill(Paint.valueOf("#ff0000"));
//        online3.setText(onlineStatus[2]);
//        online3.setTextFill(Paint.valueOf("#ff0000"));
//        online4.setText(onlineStatus[3]);
//        online4.setTextFill(Paint.valueOf("#ff0000"));
//        online5.setText(onlineStatus[4]);
//        online5.setTextFill(Paint.valueOf("#ff0000"));
//        online6.setText(onlineStatus[5]);
//        online6.setTextFill(Paint.valueOf("#ff0000"));
//        online7.setText(onlineStatus[6]);
//        online7.setTextFill(Paint.valueOf("#ff0000"));
//        online8.setText(onlineStatus[7]);
//        online8.setTextFill(Paint.valueOf("#ff0000"));
//        online9.setText(onlineStatus[8]);
//        online9.setTextFill(Paint.valueOf("#ff0000"));
//        online10.setText(onlineStatus[9]);
//        online10.setTextFill(Paint.valueOf("#ff0000"));
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        System.out.println(dateFormat.format(date));
        String temp=dateFormat.format(date);
        String[] temps=StringUtils.split(temp);
        for(String t:temps){
            System.out.println(t);
        }


        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date date1 = sdf.parse("2009/12/31 00:13:49");
        Date date2 = sdf.parse("2010/01/31 00:13:49");





        System.out.println("date1 : " + sdf.format(date1));
        System.out.println("date2 : " + sdf.format(date2));

        if (date1.compareTo(date2) > 0) {
            System.out.println("Date1 is after Date2");
        } else if (date1.compareTo(date2) < 0) {
            System.out.println("Date1 is before Date2");
        } else if (date1.compareTo(date2) == 0) {
            System.out.println("Date1 is equal to Date2");
        } else {
            System.out.println("How to get here?");
        }

        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss" );
        SimpleDateFormat sdf3 = new SimpleDateFormat("MM/dd HH:mm" );
        Date date3 = sdf2.parse("2009/12/31 12:13:49");

        System.out.println(sdf3.format(date3));

//        Date date4 = new Date();
//        System.out.println(sdf2.format(date4));


    }
}

