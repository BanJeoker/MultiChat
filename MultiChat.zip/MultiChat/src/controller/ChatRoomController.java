package controller;

import client.ChatClient;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Paint;
import org.apache.commons.lang3.StringUtils;
import sample.Main;

import java.util.Arrays;

public class ChatRoomController {
//    private String name;
    private String userID;
    private ChatClient chatClient;



    @FXML private Label name1;
    @FXML private Label name2;
    @FXML private Label name3;
    @FXML private Label name4;
    @FXML private Label name5;
    @FXML private Label name6;
    @FXML private Label name7;
    @FXML private Label name8;
    @FXML private Label name9;
    @FXML private Label name10;

    @FXML private Label online1;
    @FXML private Label online2;
    @FXML private Label online3;
    @FXML private Label online4;
    @FXML private Label online5;
    @FXML private Label online6;
    @FXML private Label online7;
    @FXML private Label online8;
    @FXML private Label online9;
    @FXML private Label online10;
    private String[] names=new String[10];
    private String[] onlineStatus=new String[10];

    @FXML public void initialize(){
        Arrays.fill(names,"");
        Arrays.fill(onlineStatus,"");


    }
    @FXML private void changeLableName(){

//        System.out.println(name);
//        name1.setText(name);
    }

    public void setExistingUser(String response) {
        String[] allnames= StringUtils.split(response);
        int len=allnames.length-3;
        for(int i=0;i<10;i++){
            if (i<len){
                names[i]=allnames[3+i];
                onlineStatus[i]="offline";
            }

        }
        name1.setText(names[0]);
        name2.setText(names[1]);
        name3.setText(names[2]);
        name4.setText(names[3]);
        name5.setText(names[4]);
        name6.setText(names[5]);
        name7.setText(names[6]);
        name8.setText(names[7]);
        name9.setText(names[8]);
        name10.setText(names[9]);

        online1.setText(onlineStatus[0]);
        online1.setTextFill(Paint.valueOf("#ff0000"));
        online2.setText(onlineStatus[1]);
        online2.setTextFill(Paint.valueOf("#ff0000"));
        online3.setText(onlineStatus[2]);
        online3.setTextFill(Paint.valueOf("#ff0000"));
        online4.setText(onlineStatus[3]);
        online4.setTextFill(Paint.valueOf("#ff0000"));
        online5.setText(onlineStatus[4]);
        online5.setTextFill(Paint.valueOf("#ff0000"));
        online6.setText(onlineStatus[5]);
        online6.setTextFill(Paint.valueOf("#ff0000"));
        online7.setText(onlineStatus[6]);
        online7.setTextFill(Paint.valueOf("#ff0000"));
        online8.setText(onlineStatus[7]);
        online8.setTextFill(Paint.valueOf("#ff0000"));
        online9.setText(onlineStatus[8]);
        online9.setTextFill(Paint.valueOf("#ff0000"));
        online10.setText(onlineStatus[9]);
        online10.setTextFill(Paint.valueOf("#ff0000"));


    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setChatClient(ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    public void handleOnlineMsg(String newOnlineUser) {

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                System.out.println("1111111");
                // Update UI here.
                for(int i=1;i<=10;i++){
                    String tempuser="#name"+i;
                    Label tempuserLabel= (Label) Main.chatRoomScene.lookup(tempuser);
                    if(tempuserLabel.getText().equals(newOnlineUser )){
                        String onlineuser="#online"+i;
//                        System.out.println("this user is "+userID+"; other is "+onlineuser);
                        Label tempOnlineLabel= (Label) Main.chatRoomScene.lookup(onlineuser);
                        tempOnlineLabel.setText("online");

                        tempOnlineLabel.setTextFill(Paint.valueOf("#33cc00"));
                        break;
                    }
                }
                return;
            }
        });


    }
//    Main.chatRoomScene
//    TableView tb = (TableView) scene.lookup("#history");

//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//
//    }
//
//    public void changeName(String n) {
//        name1.setText(n);
//    }
}
