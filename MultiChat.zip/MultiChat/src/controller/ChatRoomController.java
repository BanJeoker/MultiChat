package controller;

import client.ChatClient;
import client.UserText;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.LightBase;
import javafx.scene.control.*;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import org.apache.commons.lang3.StringUtils;
import sample.Main;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Optional;

//css

public class ChatRoomController {

    public String getUserID() {
        return userID;
    }

    //    private String name;
    private String userID="";
    private ChatClient chatClient;
    private HashMap<String, UserText> userTextMap=new HashMap<>();
    private HashMap<String, Label> userNameMap=new HashMap<>();
    private HashMap<String, Label> statusMap=new HashMap<>();
    private HashMap<String, Label> msgNumMap=new HashMap<>();
    private String currentChatCompany="";
    private String previousName="";
    private int allLength=0;


    @FXML private TextArea textMain;
    @FXML private Label labelYou;
    @FXML private TextArea textinput;
    private String[] names=new String[10];
    private String[] onlineStatus=new String[10];

    @FXML public void initialize(){
        Arrays.fill(names,"");
        Arrays.fill(onlineStatus,"");




    }
    @FXML private void buttonClearMsg(){
        textinput.setText("");
        textinput.requestFocus();
    }
    @FXML private void sendMsg() throws IOException {
        if(!textinput.getText().equals("")&&!currentChatCompany.equals("")){
            String content=textinput.getText();
//            System.out.println("first"+content);
            String recipient=currentChatCompany;
            chatClient.sendMsg(content,recipient);
            userTextMap.get(recipient).addMyText(userID,content);
            textMain.setText( userTextMap.get(recipient).getAllText());
            textMain.positionCaret(textMain.getText().length());
            textinput.setText("");
            textinput.requestFocus();
        }
    }
    @FXML private void showQuit() throws IOException {

        alertQuit();

    }

    public void alertQuit() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Quit Chat");
        alert.setHeaderText("Are you sure to quit");

        ButtonType buttonTypeOne = new ButtonType("Yes");
        ButtonType buttonTypeTwo = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);


        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == buttonTypeOne) {
//            System.out.println("1111111");
            chatClient.handleLogOff();
            Stage stage = Main.getPrimaryStage();
            stage.close();

        }
    }

    @FXML private void showAbout(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("Hello World");
        alert.setContentText("Created By Yifei Gong, MultiChat");
        alert.showAndWait();

    }

    public void setExistingUser(String response) {

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                String[] allnames= StringUtils.split(response);
                int len=allnames.length-3;
                allLength=len;
                for(int i=0;i<10;i++){
                    if (i<len){
                        names[i]=allnames[3+i];
                        onlineStatus[i]="offline";

                        //initialize textUser.
                        UserText userText=new UserText(names[i]);
                        userTextMap.put(names[i],userText);

                        //first label
                        int j=i+1;
                        String firstS="#name"+j;
                        Label first= (Label) Main.chatRoomScene.lookup(firstS);
                        first.setText(names[i]);
                        userNameMap.put(names[i],first);
                        first.setPadding(new Insets(0, 0, 0, 10));





                        first.setOnMouseClicked(event -> {
                            textMain.requestFocus();
                            if(!previousName.equals(first.getText())){
                                String currentText=textinput.getText();
                                changeLabelColor("-fx-background-color: rgb(244,244,244);",previousName,currentText);
                                currentChatCompany=first.getText();

                                previousName=first.getText();
                                first.setStyle("-fx-background-color: rgb(226,226,226);");
                                setBesideLable(currentChatCompany);
                                textMain.setText(userTextMap.get(currentChatCompany).getAllText());
                                textinput.setText(userTextMap.get(currentChatCompany).getCurrentText());
                            }
                        });


                        //second label
                        String secondS="#online"+j;

                        Label second= (Label) Main.chatRoomScene.lookup(secondS);
                        second.setText(onlineStatus[i]);
                        second.setTextFill(Paint.valueOf("#ff0000"));
                        second.setPadding(new Insets(0, 0, 0, 3));
                        statusMap.put(names[i],second);
//                        System.out.println("11111"+names[1]+"11111"+second+"11111");

                        //third label
                        String thirdS="#msgNum"+j;
                        Label third= (Label) Main.chatRoomScene.lookup(thirdS);
                        msgNumMap.put(names[i],third);


                    }

                }
                textinput.requestFocus();
                labelYou.setText("Welcom back "+userID);
                return;
            }
        });




    }

    private void changeLabelColor(String s,String name, String s2) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if (!name.equals("")){
                    userTextMap.get(name).setTextinput(s2);
                    Label first=userNameMap.get(name);
                    Label second=statusMap.get(name);

                    Label third=msgNumMap.get(name);

                    first.setStyle(s);
                    second.setStyle(s);
                    third.setStyle(s);


                }
            }
        });

    }

    private void setBesideLable(String besideL) {

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                Label temp=statusMap.get(besideL);
                Label temp2=msgNumMap.get(besideL);

                UserText user=userTextMap.get(besideL);
                user.setUnredMsgNum(0);
                temp2.setStyle("-fx-background-color: rgb(226,226,226);");
                temp.setStyle("-fx-background-color: rgb(226,226,226);");
                temp2.setText("");
                if(temp.getText().equals("offline")){
                    textinput.setPromptText(besideL+" is offline currently, but you can leave messages");
                }
                else{
                    textinput.setPromptText("");
                }


            }
        });



    }


    public void handleMsg(String response) throws ParseException {
        String[] responses=StringUtils.split(response,null,6);
//        System.out.println("response is "+response);
//        System.out.println(userTextMap.size());
        UserText tempUserText=userTextMap.get(responses[1]);


        tempUserText.addText(responses);
        if(currentChatCompany.equals(responses[1])){
            textMain.setText(tempUserText.getAllText());
            textMain.positionCaret(textMain.getText().length());
        }
        else{
            UserText user=userTextMap.get(responses[1]);
//            user.setUnredMsgNum(user.getUnredMsgNum()+1);
            int num=user.getUnredMsgNum();
            user.setUnredMsgNum(num+1);
            Label temp=msgNumMap.get(responses[1]);
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    temp.setText(""+user.getUnredMsgNum()+"msg");
                }
            });


        }



    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setChatClient(ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    public void handleOnlineMsg(String newOnlineUser) {

        Platform.runLater(new Runnable() {
            @Override
            public void run() {

//                System.out.println(statusMap.size()+"size");
                Label temp=statusMap.get(newOnlineUser);
                temp.setText("online");
                temp.setTextFill(Paint.valueOf("#33cc00"));
                return;
            }
        });

    }

    public void handleOtherLogOff(String other) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                Label temp=statusMap.get(other);
                temp.setText("offline");
                temp.setTextFill(Paint.valueOf("#ff0000"));
                return;
            }
        });

    }


    public void addNewUser(String newUserName) {
        allLength=allLength+1;
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                UserText userText=new UserText(newUserName);
                userTextMap.put(newUserName,userText);

                //first label
                String firstS="#name"+allLength;
                Label first= (Label) Main.chatRoomScene.lookup(firstS);
                first.setText(newUserName);
                userNameMap.put(newUserName,first);
                first.setPadding(new Insets(0, 0, 0, 10));

                first.setOnMouseClicked(event -> {
                    textMain.requestFocus();
                    if(!previousName.equals(first.getText())){
                        String currentText=textinput.getText();
                        changeLabelColor("-fx-background-color: rgb(244,244,244);",previousName,currentText);
                        currentChatCompany=first.getText();

                        previousName=first.getText();
                        first.setStyle("-fx-background-color: rgb(226,226,226);");
                        setBesideLable(currentChatCompany);
                        textMain.setText(userTextMap.get(currentChatCompany).getAllText());
                        textinput.setText(userTextMap.get(currentChatCompany).getCurrentText());
                    }
                });
                //second label
                String secondS="#online"+allLength;
                Label second= (Label) Main.chatRoomScene.lookup(secondS);
                second.setText("offline");
                second.setTextFill(Paint.valueOf("#ff0000"));
                second.setPadding(new Insets(0, 0, 0, 3));
                statusMap.put(newUserName,second);

                //third label
                String thirdS="#msgNum"+allLength;
                Label third= (Label) Main.chatRoomScene.lookup(thirdS);
                msgNumMap.put(newUserName,third);


            }
        });

    }
}
