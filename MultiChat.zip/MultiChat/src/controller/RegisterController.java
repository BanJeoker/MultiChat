package controller;

import client.ChatClient;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import sample.Main;

public class RegisterController {
    @FXML private TextField nameField;
    @FXML private PasswordField passwordField;

    @FXML private void registerUserToServer(){
        String userID=nameField.getText();
        String password=passwordField.getText();
        if(!userID.equals("")&&!password.equals("")) {
            ChatClient chatClient = new ChatClient("localhost", 8818,this);
            if (chatClient.connect()) {
                int registerCode = chatClient.register(userID, password);
                if(registerCode==0){
                    alertExistingUser();
                }
                else if(registerCode==1){
                    alertSuccess();
                }
            }
        }
    }

    private void alertSuccess() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success Register");
        alert.setHeaderText("Congratulation!");
        alert.setContentText("You have successfully registered to MultiChat");
        nameField.setText("");
        passwordField.setText("");
        alert.showAndWait();
        Stage stage = Main.getPrimaryStage();
        stage.setTitle("User Login");
        stage.setScene(Main.rootScene);

    }

    private void alertExistingUser() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fail Register");
        alert.setHeaderText("Oops!");
        alert.setContentText("UserID is in use,try another one");
        nameField.setText("");
        passwordField.setText("");
        alert.showAndWait();
    }

    @FXML private void returnToLogin(){
        Stage stage = Main.getPrimaryStage();
        stage.setTitle("User Login");
        stage.setScene(Main.rootScene);
    }
}
