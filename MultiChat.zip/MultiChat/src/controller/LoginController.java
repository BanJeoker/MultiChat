package controller;

import client.ChatClient;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.apache.commons.lang3.StringUtils;
import sample.Main;

import java.io.IOException;

public class LoginController {

    private ChatRoomController chatRoomController;
    @FXML private TextField nameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    private String failReason;
    private String response;
    @FXML public void initialize(){

    }
    @FXML private void userLogin() throws IOException {
        String userID=nameField.getText();
        String password=passwordField.getText();
        ChatClient chatClient=new ChatClient("localhost",8818,this,chatRoomController);
        chatRoomController.setChatClient(chatClient);

        if (chatClient.connect()){

            int logincode=chatClient.login(userID,password);

            if(logincode==1||logincode==2){                   //login ok;
                if (logincode==1){                             // no buffered msg
                    chatRoomController.setUserID(userID);
                    chatRoomController.setExistingUser(response);

                }
                Stage stage= Main.getPrimaryStage();
                stage.setTitle("Chat Room");
                stage.setScene(Main.chatRoomScene);


            }
            if(logincode==3){                   //login fail;
                alert();
            }
        }
        else{
            alertConnectionFail();
        }



    }



    private void alertConnectionFail() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Connection Fail");
        alert.setHeaderText("Oops!");
        alert.setContentText("try login again later");
        alert.showAndWait();
    }

    private void alert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fail Login");
        alert.setHeaderText("Oops!");
        alert.setContentText(getFailReason());
        alert.showAndWait();
    }

    public void loginSuccess(){
        nameField.setText("success");
    }

    public String getFailReason() {
        return failReason;
    }

    public void setFailReason(String failReason) {
        this.failReason = failReason;
    }

    public void setChatRoomController(ChatRoomController chatRoomController) {
        this.chatRoomController = chatRoomController;
    }


    public void setResponse(String response) {
        this.response = response;
    }
}
