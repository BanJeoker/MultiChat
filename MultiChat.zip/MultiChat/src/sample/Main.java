package sample;

import controller.ChatRoomController;
import controller.LoginController;
import controller.RegisterController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    private static LoginController loginController;
    private static ChatRoomController chatRoomController;
    private static RegisterController registerController;

    private static Stage pStage;
    public static Parent rootLogin;
    public static Scene rootScene;

    public static Parent ChatRoomRoot;
    public static Scene chatRoomScene;

    public static Parent RegisterRoot;
    public static Scene registerScene;

    @Override
    public void start(Stage primaryStage) throws Exception{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("/view/login.fxml"));
        rootLogin=loader.load();
        loginController=loader.getController();


        FXMLLoader loader2=new FXMLLoader();
        loader2.setLocation(Main.class.getResource("/view/chatRoom.fxml"));
        ChatRoomRoot= loader2.load();
        chatRoomController=loader2.getController();


        FXMLLoader loader3=new FXMLLoader();
        loader3.setLocation(Main.class.getResource("/view/register.fxml"));
        RegisterRoot= loader3.load();
        registerController=loader3.getController();


        loginController.setChatRoomController(chatRoomController);



        pStage=primaryStage;

        pStage.setOnCloseRequest(e->{
            if(!chatRoomController.getUserID().equals("")){
                try {
                    chatRoomController.alertQuit();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            else{
                pStage.close();
            }
        });




        rootScene=new Scene(rootLogin);
        chatRoomScene=new Scene(ChatRoomRoot);
        registerScene=new Scene(RegisterRoot);


        chatRoomScene.getStylesheets().add("/css/chatRoom.css");
        rootScene.getStylesheets().add("/css/login.css");
        registerScene.getStylesheets().add("/css/register.css");


        pStage.setTitle("User Login");
        pStage.setScene(rootScene);
        pStage.show();
    }

    public static Stage getPrimaryStage() {
        return pStage;
    }
    public static void main(String[] args) {
        launch(args);
    }
}
