package sample;

import controller.ChatRoomController;
import controller.LoginController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {
    private static LoginController loginController;
    private static ChatRoomController chatRoomController;


    private static Stage pStage;
    public static Parent rootLogin;
    public static Scene rootScene;

    public static Parent ChatRoomRoot;
    public static Scene chatRoomScene;
    @Override
    public void start(Stage primaryStage) throws Exception{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("/view/login.fxml"));
//        rootLogin= loader.load(getClass().getResource("/view/login.fxml"));
        rootLogin=loader.load();
        loginController=loader.getController();

//        System.out.println(loginController);

        FXMLLoader loader2=new FXMLLoader();
        loader2.setLocation(Main.class.getResource("/view/chatRoom.fxml"));
//        ChatRoomRoot= loader2.load(getClass().getResource("/view/chatRoom.fxml"));
        ChatRoomRoot= loader2.load();
        chatRoomController=loader2.getController();

        loginController.setChatRoomController(chatRoomController);



        pStage=primaryStage;




        rootScene=new Scene(rootLogin);
        chatRoomScene=new Scene(ChatRoomRoot);

        chatRoomScene.getStylesheets().add("/css/chatRoom.css");
        rootScene.getStylesheets().add("/css/login.css");

        pStage.setTitle("User Login");
        pStage.setScene(rootScene);
        pStage.show();
    }

    public static Stage getPrimaryStage() {
        return pStage;
    }
    public static void main(String[] args) {
        launch(args);
    }
}
