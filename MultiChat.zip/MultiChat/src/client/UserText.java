package client;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserText {
    private String userID;
    private String currentText;
    private int unredMsgNum=0;
    public String getAllText() {
        return allText;
    }

    private String allText="";
    SimpleDateFormat olddateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss" );
    DateFormat dateFormat = new SimpleDateFormat("MM/dd HH:mm");
    public UserText(String name) {
        this.userID=name;
    }


    public void addText(String[] responses) throws ParseException {
        String d=responses[3]+" "+responses[4];
        Date date=olddateFormat.parse(d);
        d=dateFormat.format(date);
        allText=allText+""+responses[1]+"("+d+"):\n"+responses[5]+"\n\n";
    }


    public void addMyText(String userID, String content) {
        Date date = new Date();
        String d=dateFormat.format(date);
        allText=allText+"You("+d+"):\n"+content+"\n\n";

    }

    public void setTextinput(String currentText) {
        this.currentText=currentText;
    }

    public String getCurrentText() {
        return currentText;
    }

    public int getUnredMsgNum() {
        return unredMsgNum;
    }

    public void setUnredMsgNum(int unredMsgNum) {
        this.unredMsgNum = unredMsgNum;
    }
}
