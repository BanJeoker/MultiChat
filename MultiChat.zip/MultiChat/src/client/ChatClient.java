package client;

import controller.LoginController;
import controller.ChatRoomController;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.net.Socket;

public class ChatClient {
    private Socket socket;
    private String serverAdd;
    private int serverPort;
    private InputStream inputStream;
    private OutputStream outputStream;
    private BufferedReader bufferedInput;
    private LoginController loginController;
    private ChatRoomController chatRoomController;


    public ChatClient(String serverAdd, int serverPort, LoginController loginController, ChatRoomController chatRoomController){
        this.serverAdd=serverAdd;
        this.serverPort=serverPort;
        this.loginController=loginController;
        this.chatRoomController=chatRoomController;

    }
    public boolean connect() {
        try {
            this.socket=new Socket(serverAdd,serverPort);
            this.outputStream=socket.getOutputStream();
            this.inputStream=socket.getInputStream();
            this.bufferedInput=new BufferedReader(new InputStreamReader(inputStream));
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }



    public int login(String userID, String password) throws IOException {
        String request="LOGON "+userID+" "+password+"\n";
        outputStream.write(request.getBytes());
        String response=bufferedInput.readLine();
            String[] responses= StringUtils.split(response);
            String success=responses[0];
            String statuscode=responses[1];

            if(success.equals("LOGOK")){
                loginController.setResponse(response);
                if(statuscode.equals("100")){
                    startReader();
                    return 1;
                }
                else if(statuscode.equals("200")){

                    return 2;
                }



            }
            else if(success.equals("LOGFAIL")){
                loginController.setFailReason("wrong password or userID");
                return 3;
            }
        return 0;
    }

    public void startReader() {
        Thread t=new Thread(){
            @Override
            public void run() {
                readMessage();
            }
        };
        t.start();
    }
    public void readMessage()  {
        String response;
        try {
            while ((response=bufferedInput.readLine())!=null){
                String responses[]= StringUtils.split(response);
                String command=responses[0];
                if("ONLINE".equals(command)){

                    handleOnlineMsg(responses[1]);

                }
//                else if("offline".equals(cmd)){
//                    handleOffline(tokens);
//                }
//                else if("msg".equals(cmd)){
//                    String[] tokenMsg=StringUtils.split(line,null,3);
//                    handleMessage(tokenMsg);
//                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            try {
                socket.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    private void handleOnlineMsg(String responses) {
        chatRoomController.handleOnlineMsg(responses);

    }

}
