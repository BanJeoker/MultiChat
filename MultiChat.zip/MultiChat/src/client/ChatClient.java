package client;

import com.sun.org.apache.regexp.internal.RE;
import controller.LoginController;
import controller.ChatRoomController;
import controller.RegisterController;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.net.Socket;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ChatClient {
    private Socket socket;
    private String serverAdd;
    private int serverPort;
    private InputStream inputStream;
    private OutputStream outputStream;
    private BufferedReader bufferedInput;
    private LoginController loginController;
    private ChatRoomController chatRoomController;
    private RegisterController registerController;
    private String userID;



    public ChatClient(String serverAdd, int serverPort, LoginController loginController, ChatRoomController chatRoomController){
        this.serverAdd=serverAdd;
        this.serverPort=serverPort;
        this.loginController=loginController;
        this.chatRoomController=chatRoomController;

    }
    public ChatClient(String serverAdd, int serverPort,RegisterController registerController){
        this.serverAdd=serverAdd;
        this.serverPort=serverPort;
        this.registerController=registerController;
    }
    public boolean connect() {
        try {
            this.socket=new Socket(serverAdd,serverPort);
            this.outputStream=socket.getOutputStream();
            this.inputStream=socket.getInputStream();
            this.bufferedInput=new BufferedReader(new InputStreamReader(inputStream));
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }



    public int login(String userID, String password) throws IOException {
        String request="LOGON "+userID+" "+password+"\n";
        outputStream.write(request.getBytes());
        String response=bufferedInput.readLine();
            String[] responses= StringUtils.split(response);
            String success=responses[0];
            String statuscode=responses[1];

            if(success.equals("LOGOK")){
                loginController.setResponse(response);
                this.userID=userID;
                if(statuscode.equals("100")){
                    startReader();
                    return 1;
                }
                else if(statuscode.equals("200")){
                    startReader();
                    return 2;
                }

            }
            else if(success.equals("LOGFAIL")){
                loginController.setFailReason("wrong password or userID");
                return 3;
            }
        return 0;
    }

    public int register(String userID, String password) {
        String request="REG "+userID+" "+password+"\n";
        try {
            outputStream.write(request.getBytes());

            String response=bufferedInput.readLine();
            String[] responses= StringUtils.split(response);
            String success=responses[0];

            if(success.equals("REGOK")){
                return 1;
            }
            else if(success.equals("DUP")){
                return 0;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void startReader() {
        Thread t=new Thread(){
            @Override
            public void run() {
                try {
                    readMessage();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        };
        t.start();
    }
    public void readMessage() throws ParseException {
        String response;
        try {
            while ((response=bufferedInput.readLine())!=null){
//                System.out.println("the response is+ "+response);
                String responses[]= StringUtils.split(response);
                String command=responses[0];

                if("ONLINE".equals(command)){
                    handleOnlineMsg(responses[1]);
                }
                else if("MSG".equals(command)){
                    String tempmsg=""+response;
                    while (!response.equals("over")){
                        response=bufferedInput.readLine();
                        if(response.equals("over")){
                           handleMsg(tempmsg);
                            break;
                        }
                        tempmsg=tempmsg+"\n"+response;
                    }
                }
                else if("LOGOFF".equals(command)){
                    chatRoomController.handleOtherLogOff(responses[1]);
                }
                else if("UPDATE".equals(command)){
                    chatRoomController.addNewUser(responses[1]);

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            try {
                socket.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }


    public void handleLogOff() throws IOException {
//         System.out.println("222222");
         String request="LOGOFF "+userID+"\n";
         outputStream.write(request.getBytes());
    }

    private void handleMsg(String response) throws ParseException {
        chatRoomController.handleMsg(response);
    }

    private void handleOnlineMsg(String responses) {

        chatRoomController.handleOnlineMsg(responses);

    }
    public void sendMsg(String content, String recipient) throws IOException {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String d=dateFormat.format(date);
        String request="SEND "+userID+" "+recipient+" "+d+" "+content+"\n"+"over\n";
        outputStream.write(request.getBytes());
    }


}
